| No | Function | Evidence | Result |
|---|---|---|---|
| 1 | Detect a ClientHello | verify-M3: one event per TLS case | PASS |
| 2 | Ignore other traffic | verify-M3 plaintext (HTTP), verify-M6.6 junk; here: 1 SSH and 100 random-byte connections, 101 received with 409621 bytes, 0 events | PASS |
| 3 | Read the cipher suites | verify-M3 tls12_two, tls13_one, cipher_cap | PASS |
| 4 | Read the versions | verify-M3 tls12_two, tls13_one, default_small | PASS |
| 5 | Flag a split ClientHello | verify-M3 default_pqc, versions_cut | PASS |
| 6 | Name the container | verify-M4 shared network namespace; verify-M5 five containers, one veth | PASS |
| 7 | Audit a violation | verify-M5 | PASS |
| 8 | Enforce a violation | verify-M6 ports 4472, 4473 | PASS |
| 9 | Fail open | verify-M6 port 4475 | PASS |
| 10 | Block unknown on request | verify-M6 port 4478 | PASS |
| 11 | Refuse the root cgroup | verify-M6 refusal root_cgroup | PASS |
| 12 | Refuse a non-veth in enforce mode | verify-M6 refusal not_a_veth (lo) | PASS |
| 13 | Detach on exit | verify-M6.6 deaths (SIGPIPE, SIGHUP, SIGUSR2), coexist (SIGINT) | PASS |
| 14 | Control | here: row 8's client, skbouncer stopped: attached 0, established True, server got the ClientHello True | PASS |
